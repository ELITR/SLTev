#!/usr/bin/env python


from  .SLTev import main

if __name__ == '__main__':
    main()
